from pathlib import Path
import xml.etree.ElementTree as E
import copy
N='http://www.w3.org/2000/svg'
INK='#452a20'
REF=Path(__file__).parent/'reused'
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def mix(c,amount):
 vals=[int(c[i:i+2],16) for i in [1,3,5]]
 return '#'+''.join(f'{round(v+(255-v)*amount if amount>=0 else v*(1+amount)):02x}' for v in vals)

def reused(character,name):
 g=copy.deepcopy(part(E.parse(REF/character/(character+'--'+name+'.svg')).getroot(),name))
 for q in g.iter():q.attrib.pop('class',None);q.attrib.pop('style',None)
 return g

def apply_clothing(r,style='tee',color='#3E7CA6',apron='none',uid='clothes'):
 shirt=part(r,'shirt');torso=shirt[1];original_d=torso.get('d');skin=shirt[0].get('fill');torso.set('fill',color)
 for q in list(shirt)[2:]:shirt.remove(q)
 trim=mix(color,-.24);light=mix(color,.25)
 def shape(g,d,fill,sw=1.7):g.append(el('path',d=d,fill=fill,stroke_width=sw))
 def line(g,d,c=trim,w=1.5):g.append(el('path',d=d,fill='none',stroke=c,stroke_width=w))
 if style=='tee':
  shape(shirt,'M139 231 Q160 247 180 231 L185 240 Q160 258 135 241Z',light)
 elif style in ['polo','shirt']:
  if style=='shirt':
   collar=copy.deepcopy(reused('finn','shirt')[2]);collar.set('fill',light);collar.set('data-part','garment-collar');shirt.append(collar)
  else:shape(shirt,'M143 232 L159 244 L177 232 L183 241 L171 251 L160 245 L149 251 L138 241Z',light)
  shape(shirt,'M157 247 H165 V'+('336' if style=='shirt' else '282')+' H157Z',mix(color,-.09),1.2)
  for y in ([258,277,296,315,332] if style=='shirt' else [257,270]):shirt.append(el('circle',cx=161,cy=y,r=1.7,fill='#FBF7EE',stroke_width=.8))
  if style=='shirt':line(shirt,'M178 264 H194 V281 Q186 286 178 281Z',trim,1.4)
 elif style=='hoodie':
  shape(shirt,'M139 232 Q129 234 126 245 Q138 263 160 262 Q183 263 194 245 Q191 234 181 232 L178 240 Q160 251 142 240Z',trim)
  line(shirt,'M133 244 Q160 263 187 244',light,1.6)
  for x in [151,169]:
   line(shirt,f'M{x} 253 Q{x-1} 264 {x} 274','#F4EDE2',1.6);shirt.append(el('circle',cx=x,cy=275,r=1.7,fill='#F4EDE2',stroke=INK,stroke_width=.7))
  shape(shirt,'M135 291 H186 L193 324 Q160 333 128 324Z',mix(color,-.10))
  line(shirt,'M138 294 L134 319 M183 294 L188 319',trim,1.5)
  shape(shirt,'M110 333 Q160 349 207 333 L209 342 Q160 361 108 342Z',trim,1.4)
 elif style=='stripes':
  defs=el('defs');clip=el('clipPath',id=uid+'-torso',clipPathUnits='userSpaceOnUse');clip.append(el('path',d=original_d));defs.append(clip);shirt.append(defs)
  bands=el('g',data_part='torso-stripes',clip_path='url(#'+uid+'-torso)',stroke='none')
  for y in range(249,348,14):bands.append(el('rect',x=103,y=y,width=114,height=5,fill=light))
  shirt.append(bands);shape(shirt,'M139 231 Q160 247 180 231 L185 240 Q160 258 135 241Z',trim)
  shape(shirt,'M110 333 Q160 349 207 333 L209 342 Q160 361 108 342Z',trim,1.4)
 # Long sleeves use one shoulder-to-wrist silhouette, with no short-sleeve edge.
 for side in ['left','right']:
  arm=part(r,'arm-viewer-'+side);upper=arm[0];upper.set('fill',color);arm[1].set('stroke',trim)
  if style in ['hoodie','stripes']:
   arm[1].set('display','none')
   sleeve_d='M113 244 Q105 243 99 256 L87 281 Q82 296 81 313 L80 332 Q92 339 105 332 L109 309 Q113 290 119 281 L128 268Z'
   upper.set('d',sleeve_d)
   if style=='stripes':
    defs=el('defs');cp=el('clipPath',id=uid+'-sleeve-'+side,clipPathUnits='userSpaceOnUse');cp.append(el('path',d=sleeve_d));defs.append(cp);arm.insert(2,defs)
    bands=el('g',clip_path='url(#'+uid+'-sleeve-'+side+')',stroke='none')
    for y in range(249,330,14):bands.append(el('rect',x=76,y=y,width=57,height=5,fill=light))
    arm.insert(3,bands)
   joint=next(q for q in arm.iter() if q.get('data-joint')==('fore-l' if side=='left' else 'fore-r'));content=joint[0]
   # Expose only the wrist under the cuff; the old elbow edge is removed.
   content[0].set('d','M81 329 Q92 335 105 329 L104 341 Q92 351 80 341Z')
   content[1].set('display','none')
   cuff=el('g',data_part='garment-fore-'+side)
   shape(cuff,'M81 323 Q93 330 106 323 L105 332 Q92 339 80 332Z',trim,1.3)
   content.insert(2,cuff)
 # Existing apron slot: no apron, cherry apron or waistcoat.
 ap=part(r,'apron')
 if apron=='none':
  for q in list(ap):ap.remove(q)
 elif apron=='apron_cherry':
  for q in ap.iter():
   if q.get('fill') and q.get('fill')!='none':q.set('fill','#B34665' if q.get('fill')=='#849880' else '#FFF1D5' if q.tag.endswith('circle') else '#D8547A')
   if q.get('stroke') and q.get('stroke') not in [INK,'none']:q.set('stroke','#AD4262')
 elif apron=='waistcoat':
  for q in list(ap):ap.remove(q)
  shape(ap,'M139 233 L160 260 L181 233 Q196 236 204 248 L200 294 L209 343 Q188 354 165 348 L160 341 L155 348 Q131 354 111 343 L120 294 L116 247 Q125 236 139 233Z','#5C4033')
  line(ap,'M139 234 L146 264 L160 275 L174 264 L181 234','#AA8871',1.6)
  line(ap,'M160 275 V340','#3D2B24',1.5)
  for y in [282,304,326]:ap.append(el('circle',cx=160,cy=y,r=2.5,fill='#C9A96A',stroke_width=.9))
  line(ap,'M125 307 L146 309 M174 309 L195 307','#AA8871',1.7)
 r.set('data-garment-style',style);r.set('data-garment-color',color);r.set('data-apron-item',apron);return r


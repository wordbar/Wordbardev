from pathlib import Path
import xml.etree.ElementTree as E
import copy
N="http://www.w3.org/2000/svg"
INK="#452a20"
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def save(r,p):p.parent.mkdir(parents=True,exist_ok=True);E.ElementTree(r).write(p,encoding='unicode',xml_declaration=True)
def light(c,m=.24):return '#'+''.join(f'{round(int(c[i:i+2],16)+(255-int(c[i:i+2],16))*m):02x}' for i in [1,3,5])
def hair_geometry(style,color):
 back=el('g',data_part='hair-back',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 front=el('g',data_part='hair-front',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 high=light(color)
 def shape(d,container=front):container.append(el('path',d=d,fill=color))
 def detail(d,container=front,w=2.2):container.append(el('path',d=d,fill='none',stroke=high,stroke_width=w))
 # Rear hair is placed below body/neck by make(), not merely behind the face.
 if style=='bob':
  shape('M102 210 C80 199 82 136 97 110 C106 81 130 72 160 73 C191 72 215 87 226 113 C240 148 238 194 217 215 Q207 221 198 211 Q179 222 160 218 Q140 225 121 212 Q111 221 102 210Z',back)
  detail('M99 144 Q90 177 103 197 M220 146 Q228 178 216 200',back)
  shape('M104 165 Q91 141 105 112 Q118 83 143 78 Q174 65 200 79 Q225 93 224 125 L216 184 Q211 203 202 208 L201 128 Q188 132 179 120 L178 131 Q163 130 155 118 L153 132 Q134 132 119 127 L118 202 Q108 199 105 186Z')
  detail('M113 115 Q124 92 143 91 M154 88 Q161 108 167 120 M184 89 Q201 98 211 122 M110 151 L111 181 M210 150 L208 182')
 elif style=='bun':
  # Reuse Priyanka's approved bun-and-back-hair at a size appropriate to this head.
  raw=Path(__file__).parent/'reused/priyanka--high-bun-and-back-hair.svg'
  g=copy.deepcopy(part(E.parse(raw).getroot(),'high-bun-and-back-hair'))
  for q in g.iter():
   q.attrib.pop('style',None);q.attrib.pop('class',None)
   if q.get('fill') and q.get('fill')!='none':q.set('fill',color)
   if q.get('stroke') and q.get('stroke') not in ['none',INK]:q.set('stroke',high)
  g.set('transform','translate(160 70) scale(0.76 0.84) translate(-160 -70)');back.append(g)
  shape('M108 158 Q98 132 106 110 C115 83 135 74 160 74 C190 74 209 83 214 110 Q223 134 212 158 L205 165 L200 130 Q188 111 176 105 Q162 124 142 126 L150 112 Q136 133 118 138 L116 165Z')
  detail('M115 115 Q133 92 158 87 M143 113 Q161 96 169 85 M183 89 Q201 102 207 126')
 elif style=='ponytail':
  shape('M207 93 Q231 75 243 97 Q256 113 246 139 Q239 156 248 178 Q262 204 246 230 Q239 248 225 247 L211 253 Q221 236 218 220 Q210 201 218 183 Q224 164 217 151 Q203 137 211 120Z',back)
  detail('M230 110 Q242 126 232 147 Q227 164 235 184 Q247 210 230 231',back)
  shape('M108 158 Q98 132 106 110 C115 83 135 74 160 74 C190 74 209 83 214 110 Q223 134 212 158 L205 165 L200 130 Q188 111 176 105 Q162 124 142 126 L150 112 Q136 133 118 138 L116 165Z')
  detail('M115 115 Q133 92 158 87 M143 113 Q161 96 169 85 M183 89 Q201 102 207 126')
  # Visible tie at the joined tail root; part of this existing hairstyle.
  front.append(el('path',d='M211 106 Q218 102 224 108 L224 115 Q218 110 212 114Z',fill='#d98fa3',stroke_width=1.5))
 elif style=='longstraight':
  # One visible outer silhouette; front crown exactly shares the rear dome.
  # Rear remains behind body for correct shoulder depth.
  shape('M100 132 C100 94 126 66 160 66 C194 66 220 94 220 132 L220 293 Q220 304 211 306 L202 300 Q181 309 160 305 Q137 310 118 300 L109 306 Q100 304 100 293Z',back)
  # No inset outer contour or long separate face-framing strips.
  shape('M100 132 C100 94 126 66 160 66 C194 66 220 94 220 132 L219 161 L209 169 L202 134 Q178 124 160 102 Q142 124 118 134 L111 169 L101 161Z')
  detail('M160 79 L160 99 M146 88 Q136 109 116 123 M174 88 Q184 109 204 123',w=1.9)
 elif style=='longwave':
  shape('M101 287 Q85 273 94 239 Q80 219 94 199 Q83 174 101 153 Q87 117 101 89 Q116 65 150 71 Q176 61 199 76 Q226 82 229 114 Q240 136 226 157 Q240 179 228 199 Q243 224 229 244 Q240 267 225 288 L211 302 L198 293 Q178 308 160 300 Q140 311 123 297 L111 306Z',back)
  detail('M101 177 Q93 192 104 208 Q93 227 105 244 Q97 261 111 281 M219 176 Q231 194 219 210 Q231 228 220 247 Q230 265 215 285',back)
  shape('M109 164 Q98 141 107 118 Q119 84 144 77 Q164 67 184 78 Q212 84 218 109 Q225 136 213 161 L216 184 Q225 199 216 212 Q208 225 216 239 L208 248 Q193 237 202 221 Q211 205 203 194 L198 136 Q183 126 176 108 Q164 128 144 130 L151 112 Q134 136 119 139 L117 167 Q109 182 117 196 Q124 212 114 225 L115 241 Q103 238 104 225 Q113 209 104 195 Q98 181 107 168Z')
  detail('M115 118 Q130 98 150 94 M145 115 Q162 99 167 88 M185 94 Q203 105 209 127 M111 175 Q105 186 113 195 M210 190 Q220 203 210 216 M111 215 Q118 226 111 233')
 elif style=='waves':
  shape('M107 241 Q90 237 100 215 Q89 200 100 181 Q88 168 102 148 Q91 116 106 89 Q121 68 148 73 Q174 63 199 78 Q223 87 227 115 Q238 138 224 157 Q237 178 225 195 Q238 215 226 230 L229 242 L216 250 L205 241 L196 248 L184 239 L160 243 L137 241 L124 249 L114 242 L105 250Z',back)
  detail('M101 175 Q95 191 107 203 Q99 220 110 235 M222 174 Q232 192 221 205 Q231 220 219 235',back)
  shape('M109 162 Q99 136 108 115 Q119 86 146 77 Q165 68 184 78 Q211 86 218 110 Q225 137 213 161 L215 181 Q223 197 214 208 L218 220 L209 231 Q199 224 205 213 Q212 203 204 191 L199 134 Q183 125 176 108 Q163 129 144 130 L151 112 Q134 135 119 139 L117 168 Q108 182 116 193 L111 203 Q102 197 106 185 L108 173Z')
  detail('M115 117 Q130 98 148 95 M145 115 Q160 99 167 88 M185 95 Q203 107 209 126 M210 178 Q218 193 209 204 M110 180 Q105 190 111 195')
 return back,front

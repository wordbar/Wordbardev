import xml.etree.ElementTree as E
import math
N='http://www.w3.org/2000/svg';E.register_namespace('',N)
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def save(r,p):p.parent.mkdir(parents=True,exist_ok=True);E.ElementTree(r).write(p,encoding='unicode',xml_declaration=True)
SHAPES={'round':(12,13.07,13.07,0),'tall':(11.5,15,14,0),'almond':(13,7.3,7.8,0),'sleepy':(12.5,5.0,10.2,0),'wide':(13.2,14.2,13.8,0),'upturned':(13,8.7,8.3,-.19)}
LASHES=['none','short','classic','long','flick'];EXPRS=['normal','happy','delighted','thinking','sad','wow','blink'];INK='#452a20'
COLORS={'Blue':'#4E6E8E','Grey-blue':'#5E7892','Brown':'#6E4A2E','Dark brown':'#3F2B20','Amber':'#A0672A','Honey':'#8E6B2E','Hazel':'#7A6A3A','Green':'#4E7A55','Grey':'#70777C','Violet':'#6A5A8E'}
SKINS=['#F6DDCC','#F2D3B3','#F0C9A0','#E8B88A','#D9A574','#C68A55','#B5793F','#8D5A3B','#744A30','#5C3A24']
metrics=[]
def dim(shape,expr):
 rx,up,dn,tilt=SHAPES[shape];m=1.08 if expr=='wow' else .96 if expr=='sad' else 1
 return rx*m,up*m,dn*m,tilt

def upper(shape,cx,di,t,expr='normal'):
 rx,up,dn,tilt=dim(shape,expr);x=rx*t
 z=max(0,1-t*t)
 power=1 if shape=='almond' else .7 if shape=='sleepy' else .5
 return (cx+x,163+tilt*di*x-up*z**power)
def lower(shape,cx,di,t,expr='normal'):
 rx,up,dn,tilt=dim(shape,expr);x=rx*t;power=1 if shape=='almond' else .5
 return (cx+x,163+tilt*di*x+dn*max(0,1-t*t)**power)
def smooth(points,close=False):
 # Catmull-Rom cubic interpolation through the common boundary samples.
 p=points;out=f'M{p[0][0]:.4f} {p[0][1]:.4f}'
 for i in range(len(p)-1):
  p0=p[max(0,i-1)];p1=p[i];p2=p[i+1];p3=p[min(len(p)-1,i+2)]
  c1=(p1[0]+(p2[0]-p0[0])/6,p1[1]+(p2[1]-p0[1])/6);c2=(p2[0]-(p3[0]-p1[0])/6,p2[1]-(p3[1]-p1[1])/6)
  out+=f' C{c1[0]:.4f} {c1[1]:.4f} {c2[0]:.4f} {c2[1]:.4f} {p2[0]:.4f} {p2[1]:.4f}'
 return out+(' Z' if close else '')
def bound(shape,cx,di,expr):
 # Angle samples are dense at the corners; these exact samples anchor lashes.
 ts=[-math.cos(math.pi*i/32) for i in range(33)]
 u=[upper(shape,cx,di,t,expr) for t in ts];l=[lower(shape,cx,di,t,expr) for t in ts]
 return u,l

def eye_family(shape,lash,color,expr,uid):
 g=el('g',data_part='eyes',data_eye_shape=shape,data_lash_style=lash,data_expression=expr,stroke=INK,stroke_linecap='round',stroke_linejoin='round')
 defs=el('defs');g.append(defs)
 for cx,di in [(134,-1),(186,1)]:
  eg=el('g',data_part='eye-left' if di<0 else 'eye-right');g.append(eg)
  if expr in ['delighted','blink']:
   # Same positions and 24-unit width, eyelash anchors computed on this closed arc.
   def lidpt(t):return (cx+12*t,164+(-5 if expr=='delighted' else 2)*(1-t*t))
   pts=[lidpt(-1+2*i/32) for i in range(33)]
   eg.append(el('path',d=smooth(pts),fill='none',stroke_width=2.8));anchor=lambda t:lidpt(t)
  else:
   u,l=bound(shape,cx,di,expr);d=smooth(u+l[::-1][1:],True)
   cp=el('clipPath',id=uid+'-'+str(cx),clipPathUnits='userSpaceOnUse');cp.append(el('path',d=d));defs.append(cp)
   eg.append(el('path',data_part='eye-white',d=d,fill='#fffaf0',stroke='none'))
   rx,up,dn,tilt=dim(shape,expr)
   total=up+dn;iry=min(9.4,total*.44);irx=min(6.5,total*.36)
   gazeX=2 if expr=='thinking' else 0;gazeY=-1 if expr=='thinking' else 1 if expr=='sad' else 0
   iy=163+(dn-up)*.32+1+gazeY
   inner=el('g',clip_path='url(#'+uid+'-'+str(cx)+')',stroke='none')
   inner.append(el('ellipse',cx=cx+gazeX,cy=iy,rx=irx,ry=iry,fill=color))
   inner.append(el('ellipse',cx=cx+gazeX,cy=iy-.7,rx=irx*.54,ry=iry*.70,fill='#302119'))
   inner.append(el('circle',cx=cx+gazeX-irx*.43,cy=iy-iry*.57,r=min(2.4,iry*.26),fill='#ffffff'))
   if shape=='wide':inner.append(el('circle',cx=cx+gazeX+irx*.42,cy=iy+iry*.35,r=1.0,fill='#ffffff'))
   eg.append(inner);eg.append(el('path',data_part='upper-lid',d=smooth(u),fill='none',stroke_width=3 if shape=='sleepy' else 2.7))
   anchor=lambda t:upper(shape,cx,di,t,expr)
  if lash=='none':continue
  # Revised: compact outer-corner fans, curved filled ribbons with sharp tips.
  # Roots remain attached to the shared lid; width tapers continuously to zero.
  styles={
   'short':[(.988,3.6,-2.6,1.35),(.91,2.2,-2.8,1.15)],
   'classic':[(.988,5.3,-3.8,1.75),(.90,3.7,-4.4,1.55)],
   'long':[(.991,6.8,-4.6,1.95),(.92,5.0,-5.8,1.75),(.82,3.3,-5.5,1.50)],
   'flick':[(.998,7.0,-3.6,2.05),(.93,3.1,-3.2,1.3)]}
  for t,dx,dy,width in styles[lash]:
   x,y=anchor(di*t)
   if expr in ['blink','delighted']:dx*=.84;dy*=.78;width*=.9
   dx*=di
   p0=(x,y);p1=(x+dx*.30,y+.20);p2=(x+dx*.92,y+dy*.38);p3=(x+dx,y+dy)
   left=[];right=[]
   for i in range(25):
    a=i/24;b=1-a
    px=b*b*b*p0[0]+3*b*b*a*p1[0]+3*b*a*a*p2[0]+a*a*a*p3[0]
    py=b*b*b*p0[1]+3*b*b*a*p1[1]+3*b*a*a*p2[1]+a*a*a*p3[1]
    tx=3*b*b*(p1[0]-p0[0])+6*b*a*(p2[0]-p1[0])+3*a*a*(p3[0]-p2[0])
    ty=3*b*b*(p1[1]-p0[1])+6*b*a*(p2[1]-p1[1])+3*a*a*(p3[1]-p2[1])
    norm=math.hypot(tx,ty);nx=-ty/norm;ny=tx/norm
    half=width*.5*(1-a)**.85
    left.append((px+nx*half,py+ny*half));right.append((px-nx*half,py-ny*half))
   # Solid silhouette avoids blunt line caps at small display sizes.
   pts=left+right[::-1]
   d='M'+' L'.join(f'{a:.4f} {b:.4f}' for a,b in pts)+' Z'
   eg.append(el('path',data_part='lash',d=d,fill=INK,stroke='none',data_taper='root-to-point',data_root_x=f'{x:.4f}',data_root_y=f'{y:.4f}'))
   metrics.append({'shape':shape,'lash':lash,'expression':expr,'eye':di,'root':[x,y],'tip':[x+dx,y+dy],'t':di*t})

 return g

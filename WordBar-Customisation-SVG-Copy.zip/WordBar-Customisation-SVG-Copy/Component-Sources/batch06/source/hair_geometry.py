from pathlib import Path
import xml.etree.ElementTree as E
import copy,math
N="http://www.w3.org/2000/svg"
INK="#452a20"
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def save(r,p):p.parent.mkdir(parents=True,exist_ok=True);E.ElementTree(r).write(p,encoding='unicode',xml_declaration=True)
def light(c,m=.24):return '#'+''.join(f'{round(int(c[i:i+2],16)+(255-int(c[i:i+2],16))*m):02x}' for i in [1,3,5])
def ref_component(character,name,color):
 p=Path(__file__).parent/'reused'/character/(character+'--'+name+'.svg')
 g=copy.deepcopy(part(E.parse(p).getroot(),name))
 for q in g.iter():
  q.attrib.pop('style',None);q.attrib.pop('class',None)
  if name!='hair-ties' and q.get('fill') and q.get('fill')!='none':q.set('fill',color)
  if q.get('stroke') and q.get('stroke') not in ['none',INK]:q.set('stroke',color if float(q.get('stroke-width','1'))>=4 else light(color))
 return g

def hair_geometry(style,color,skin='#E8B88A'):
 back=el('g',data_part='hair-back',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 front=el('g',data_part='hair-front',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 high=light(color)
 def shape(d,container=front,stroke=None):
  q=el('path',d=d,fill=color)
  if stroke:q.set('stroke',stroke)
  container.append(q)
 def detail(d,container=front,w=2.2,c=None):container.append(el('path',d=d,fill='none',stroke=c or high,stroke_width=w))
 if style=='curls':
  back.append(ref_component('finn','hair-back',color));front.append(ref_component('finn','ginger-curls',color))
 elif style=='puffs':
  back.append(ref_component('amara','twin-puffs',color));back.append(ref_component('amara','hair-ties',color));front.append(ref_component('amara','curly-fringe',color));front.append(ref_component('amara','side-curls',color))
 elif style=='frizz':
  back.append(ref_component('iris','shoulder-curls-back',color));front.append(ref_component('iris','curly-fringe-and-side-locks',color))
 elif style=='afro':
  # One broad rounded mass with a restrained scalloped contour.
  n=28;cx=160;cy=111;rx=88;ry=84
  def point(a,m=1):return (cx+rx*m*math.cos(a),cy+ry*m*math.sin(a))
  def segment(i):
   a=2*math.pi*i/n;b=2*math.pi*(i+1)/n;c=point((a+b)/2,1.065);e=point(b)
   return f' Q{c[0]:.3f} {c[1]:.3f} {e[0]:.3f} {e[1]:.3f}'
  p=point(0);d=f'M{p[0]} {p[1]}'+''.join(segment(i) for i in range(n))+' Z';shape(d,back)
  # Reuse the exact upper outer contour, so there is no inset second crown.
  p=point(math.pi);upper=f'M{p[0]} {p[1]}'+''.join(segment(i) for i in range(n//2,n))
  inner=' Q250 139 230 151 L215 161 L208 137 Q202 117 188 120 Q179 111 169 122 Q159 113 149 123 Q136 112 125 127 L114 151 L105 159 Q80 156 78 138 Z'
  shape(upper+inner,stroke='none')
  detail('M105 159 L114 151 L125 127 Q136 112 149 123 Q159 113 169 122 Q179 111 188 120 Q202 117 208 137 L215 161',c=INK,w=2.1)
  detail('M102 94 Q110 84 120 91 M134 63 Q145 54 155 62 M172 62 Q182 53 193 63 M213 92 Q224 84 232 94 M88 129 Q96 121 104 129 M217 133 Q227 125 235 134',front,w=2)
 elif style=='cornrows':
  shape('M111 151 L108 133 C108 103 131 78 160 78 C189 78 212 103 212 133 L210 151 L203 151 L198 130 Q177 119 160 123 Q142 119 122 130 L117 151Z')
  # Scalp channels follow the head surface; no isolated floating braid lines.
  detail('M121 128 C117 110 130 92 147 82 M139 124 C134 109 143 91 153 81 M160 122 L160 81 M181 124 C186 109 177 91 167 81 M199 128 C203 110 190 92 173 82',w=1.7,c=skin)
  detail('M147 94 Q151 98 155 94 M145 104 Q150 108 155 104 M145 114 Q150 118 155 114 M165 94 Q169 98 173 94 M165 104 Q170 108 175 104 M165 114 Q170 118 175 114 M126 99 Q130 103 134 99 M123 110 Q127 114 131 110 M124 121 Q128 125 132 121 M186 99 Q190 103 194 99 M189 110 Q193 114 197 110 M188 121 Q192 125 196 121',w=1.25)
 elif style=='locs':
  shape('M105 165 Q86 145 100 99 Q113 67 145 64 Q174 57 199 69 Q226 80 225 117 L218 179 L204 216 L189 211 L130 211 L111 220 L100 199Z',back)
  # Chunky curved loc silhouettes, with rounded ends and sparse detail.
  def loc(d,container=front,w=13):
   container.append(el('path',d=d,fill='none',stroke=INK,stroke_width=w+2.8,stroke_linecap='round'))
   container.append(el('path',d=d,fill='none',stroke=color,stroke_width=w,stroke_linecap='round'))
  for d in ['M107 122 Q86 157 103 192 L103 215','M119 128 Q101 160 115 184 L113 226','M202 124 Q225 153 213 185 L216 218','M215 116 Q238 151 226 178 L226 205']:loc(d,back,13)
  shape('M105 151 Q95 113 115 78 Q139 58 161 70 Q187 58 208 79 Q226 103 216 151 L207 163 L200 132 Q183 126 175 111 Q161 127 145 125 Q130 134 120 125 L114 164Z')
  for d in ['M117 95 Q104 115 112 138','M134 80 Q116 104 124 124','M153 76 Q142 99 148 118','M173 76 Q159 101 168 124','M190 83 Q181 103 187 122','M205 96 Q206 117 207 145']:loc(d,w=12)
  detail('M133 88 Q123 102 126 114 M172 84 Q165 103 170 114 M218 156 Q222 173 219 186',w=1.8)
 return back,front

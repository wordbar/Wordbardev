from pathlib import Path
import xml.etree.ElementTree as E
import copy
N="http://www.w3.org/2000/svg"
INK="#452a20"
def dark(c,m):return "#"+"".join(f"{round(int(c[i:i+2],16)*m):02x}" for i in [1,3,5])
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def save(r,p):p.parent.mkdir(parents=True,exist_ok=True);E.ElementTree(r).write(p,encoding='unicode',xml_declaration=True)
def light(c,m=.24):return '#'+''.join(f'{round(int(c[i:i+2],16)+(255-int(c[i:i+2],16))*m):02x}' for i in [1,3,5])
def ref_component(character,name,color):
 p=Path(__file__).parent/'reused'/character/(character+'--'+name+'.svg')
 g=copy.deepcopy(part(E.parse(p).getroot(),name))
 for q in g.iter():
  q.attrib.pop('style',None);q.attrib.pop('class',None)
  if q.get('fill') in ['#d69a91','#6c5d3e']:q.set('fill','#d98fa3')
  elif q.get('fill') and q.get('fill')!='none':q.set('fill',color)
  if q.get('stroke') and q.get('stroke') not in ['none',INK]:q.set('stroke',light(color))
 return g

def hair_geometry(style,color,skin='#E8B88A'):
 back=el('g',data_part='hair-back',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 front=el('g',data_part='hair-front',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 middle=el('g',data_part='hair-middle',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 high=light(color)
 def shape(d,container=front,fill=None):container.append(el('path',d=d,fill=fill or color))
 def detail(d,container=front,w=2.2):container.append(el('path',d=d,fill='none',stroke=high,stroke_width=w))
 def mirror(g):
  wrap=el('g',transform='translate(320 0) scale(-1 1)');wrap.append(g);return wrap
 def connector(side=1):
  d='M204 153 Q222 174 216 198 L209 215 L198 205 Q210 185 200 168Z'
  q=el('path',d=d,fill=color)
  back.append(q if side==1 else mirror(q))
 def swept_cap(reverse=False):
  g=el('g');g.append(el('path',d='M108 158 Q98 132 106 110 C115 83 135 74 160 74 C190 74 209 83 214 110 Q223 134 212 158 L205 165 L200 130 Q188 111 176 105 Q162 124 142 126 L150 112 Q136 133 118 138 L116 165Z',fill=color))
  g.append(el('path',d='M115 115 Q133 92 158 87 M143 113 Q161 96 169 85 M183 89 Q201 102 207 126',fill='none',stroke=high,stroke_width=2.2));front.append(mirror(g) if reverse else g)
 def centre_cap():
  shape('M108 158 Q98 129 107 108 C116 82 139 74 160 74 C181 74 204 82 213 108 Q222 129 212 158 L205 164 L200 133 Q180 126 160 105 Q140 126 120 133 L115 164Z')
  detail('M160 85 L160 102 M149 88 Q135 102 119 120 M171 88 Q185 102 201 120')
 if style=='plait':
  connector(1)
  middle.append(ref_component('hana','side-plait',color));swept_cap()
 elif style=='sidebraid':
  connector(-1)
  middle.append(mirror(ref_component('freya','side-plait',color)));swept_cap(reverse=True)
 elif style=='twinbraids':
  connector(-1);connector(1)
  for side in [-1,1]:
   g=el('g',transform='translate(205 190) scale(0.85 0.85) translate(-205 -190)');g.append(ref_component('hana','side-plait',color));middle.append(g if side==1 else mirror(g))
  centre_cap()
 elif style=='spacebuns':
  for x in [113,207]:
   bun=ref_component('librarian','high-bun',color);bun.set('transform',f'translate({x-161} -13)');back.append(bun)
  centre_cap()
 elif style=='topknot':
  bun=ref_component('librarian','high-bun',color);bun.set('transform','translate(160 60) scale(0.86 0.90) translate(-161 -78)');back.append(bun)
  shape('M110 153 L107 132 C106 102 130 78 160 78 C190 78 214 102 213 132 L210 153 L203 152 L199 130 Q181 117 160 120 Q139 117 121 130 L117 153Z')
  detail('M123 113 Q139 94 154 87 M160 89 L160 111 M166 87 Q181 94 197 113')
  shape('M146 77 Q160 82 174 77 L175 82 Q160 86 145 82Z',fill=dark(color,.68))
 elif style=='curtains':
  shape('M106 181 Q93 160 100 125 C102 89 128 71 160 70 C192 70 216 89 219 125 Q228 160 214 182 L205 190 L198 158 L122 158 L115 190Z',back)
  shape('M106 181 Q93 160 100 125 C102 89 128 71 160 70 C192 70 216 89 219 125 Q228 160 214 182 L205 190 L201 154 Q198 136 183 128 Q169 119 160 110 Q151 119 137 128 Q122 136 119 154 L115 190Z')
  detail('M160 83 L160 107 M149 87 Q138 112 119 126 M171 87 Q182 112 201 126 M112 140 Q109 158 112 174 M208 140 Q211 158 208 174')
 return back,middle,front

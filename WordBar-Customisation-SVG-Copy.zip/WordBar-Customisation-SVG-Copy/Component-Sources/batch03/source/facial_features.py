import xml.etree.ElementTree as E
import math
N='http://www.w3.org/2000/svg';E.register_namespace('',N)
INK='#452a20';BROWS=['natural','thin','thick','arched','straight'];CHEEKS=['plain','rosy','freckles'];FH=['none','mustache','beard_short','beard_short_mustache','beard_long','beard_long_mustache'];EXPR=['normal','happy','delighted','thinking','sad','wow','blink']
SKINS=['#F6DDCC','#F2D3B3','#F0C9A0','#E8B88A','#D9A574','#C68A55','#B5793F','#8D5A3B','#744A30','#5C3A24'];HAIRS=['#171310','#2B1B12','#6B3A22','#8A6B3A','#A67B52','#B5502A','#C4622D','#D9955A','#C9A227','#E6DCC2','#7A7A7A','#C9CCD1']
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def shade(c,m):return '#'+''.join(f'{round(int(c[i:i+2],16)*m):02x}' for i in [1,3,5])
def save(r,p):p.parent.mkdir(parents=True,exist_ok=True);E.ElementTree(r).write(p,encoding='unicode',xml_declaration=True)

def brow_geometry(style,expr,hair):
 g=el('g',data_part='brows',data_brow_style=style,stroke='none',fill=shade(hair,.68))
 # Left-eye curve specified outside-to-inside; mirror for the right eye.
 yy={'normal':(141,137,140),'happy':(140,136,139),'delighted':(138,133,137),'sad':(144,136,137),'wow':(136,131,135),'blink':(141,137,140),'thinking':(142,141,143)}[expr]
 width={'natural':2.6,'thin':1.4,'thick':4.1,'arched':2.6,'straight':2.6}[style]
 for di in [-1,1]:
  y0,yc,y1=yy
  if expr=='thinking' and di==1:y0,yc,y1=(136,132,138)
  if style=='arched':yc-=2.5
  if style=='straight':yc=(y0+y1)/2-.35
  # Filled eyebrow with tapered outer end and a softly rounded inner end.
  p0=(121,y0);p1=(133.5,yc);p2=(146,y1);up=[];dn=[]
  for i in range(25):
   t=i/24;u=1-t;x=u*u*p0[0]+2*u*t*p1[0]+t*t*p2[0];y=u*u*p0[1]+2*u*t*p1[1]+t*t*p2[1]
   tx=2*u*(p1[0]-p0[0])+2*t*(p2[0]-p1[0]);ty=2*u*(p1[1]-p0[1])+2*t*(p2[1]-p1[1]);length=math.hypot(tx,ty)
   half=width*.5*(.30+.70*math.sin(math.pi*t)**.5);nx=-ty/length;ny=tx/length
   for arr,sign in [(up,-1),(dn,1)]:
    xx=x+sign*nx*half;arr.append((xx if di==-1 else 320-xx,y+sign*ny*half))
  d='M'+' L'.join(f'{x:.4f} {y:.4f}' for x,y in up+dn[::-1])+' Z';g.append(el('path',d=d))
 return g

def cheeks(style,skin):
 g=el('g',data_part='cheeks',data_cheek_style=style,stroke='none')
 if style=='rosy':
  for cx in [127.5,192.5]:g.append(el('ellipse',cx=cx,cy=188.5,rx=6.4,ry=2.7,fill='#db8275',opacity='.42'))
 if style=='freckles':
  for di in [-1,1]:
   for x,y,r in [(124,186.7,.85),(129,185.4,.72),(133,187.4,.80),(126,190.1,.63),(131,190,.60)]:g.append(el('circle',cx=x if di==-1 else 320-x,cy=y,r=r,fill=shade(skin,.58),opacity='.82'))
 return g

def facial_hair(style,hair):
 g=el('g',data_part='facial-hair',data_facial_hair=style,stroke=INK,stroke_width=1.5,stroke_linejoin='round',stroke_linecap='round')
 if style=='none':return g
 if style.startswith('beard_short'):
  d='M113 177 Q114 202 128 217 Q141 230 160 231 Q179 230 192 217 Q206 202 207 177 L199 181 Q198 196 185 203 L180 214 Q160 226 140 214 L135 203 Q122 196 121 181 Z'
  g.append(el('path',d=d,fill=hair));g.append(el('path',d='M125 206 Q130 217 143 223 M195 206 Q190 217 177 223',fill='none',stroke=shade(hair,.72),stroke_width=1.2))
 if style.startswith('beard_long'):
  d='M113 177 Q113 202 122 217 L128 239 L141 251 L148 259 L160 265 L172 259 L179 251 L192 239 L198 217 Q207 202 207 177 L199 181 Q198 196 185 203 L180 212 Q160 224 140 212 L135 203 Q122 196 121 181 Z'
  g.append(el('path',d=d,fill=hair));g.append(el('path',d='M128 214 Q131 234 145 245 M148 229 Q151 244 160 252 M191 214 Q187 235 177 244',fill='none',stroke=shade(hair,.72),stroke_width=1.2))
 if style=='mustache' or style.endswith('_mustache'):
  # Fuller natural chevron, based on the user's supplied moustache reference.
  # Broad centre and downward outer ends; upper lip remains exposed.
  g.append(el('path',data_source='user-reference-chevron-redraw',d='M160 185.5 C155 182.8 149 183.8 145 186.2 C140 188.2 137 191.4 136 195 C142 193.5 146 190.4 151 189.8 C155 189.2 157 189.8 160 188.8 C163 189.8 165 189.2 169 189.8 C174 190.4 178 193.5 184 195 C183 191.4 180 188.2 175 186.2 C171 183.8 165 182.8 160 185.5 Z',fill=hair,stroke_width=1.1))

 return g

def nose(skin):
 g=el('g',data_part='nose');g.append(el('ellipse',cx=160,cy=181,rx=3.1,ry=2.5,fill=shade(skin,.69),stroke='none'));return g

def mouth(expr):
 g=el('g',data_part='mouth',data_expression=expr,stroke=INK,stroke_linecap='round',stroke_linejoin='round')
 if expr in ['happy','delighted']:
  g.append(el('path',d='M146 193 Q160 198 174 193 Q173 206 160 207 Q147 205 146 193Z',fill='#72392d',stroke_width=1.7));g.append(el('path',d='M150 195 Q160 197 170 195 L169 199 H151Z',fill='#fff6e6',stroke='none'));g.append(el('path',d='M153 204 Q160 201 167 204 Q160 208 153 204Z',fill='#df9284',stroke='none'))
 elif expr=='wow':
  g.append(el('ellipse',cx=160,cy=198,rx=5.5,ry=7,fill='#72392d',stroke_width=1.7));g.append(el('ellipse',cx=160,cy=201.5,rx=3.1,ry=1.5,fill='#df9284',stroke='none'))
 else:g.append(el('path',d='M149 199 Q160 192 171 199' if expr=='sad' else 'M152 197 Q160 194 167 198' if expr=='thinking' else 'M149 194 Q160 200 171 194',fill='none',stroke_width=2))
 return g

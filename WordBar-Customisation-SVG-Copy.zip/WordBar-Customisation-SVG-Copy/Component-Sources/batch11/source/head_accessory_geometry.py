from pathlib import Path
import xml.etree.ElementTree as E
import copy,math
N='http://www.w3.org/2000/svg'
INK='#452a20'
REF=Path(__file__).parent/'reused'
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
TOP={'bald':82,'crop':77,'flop':67,'side':76,'buzz':80,'shortquiff':65,'pixie':72,'bob':68,'bun':70,'ponytail':70,'longstraight':66,'longwave':66,'waves':74,'curls':65,'puffs':84,'frizz':68,'afro':28,'cornrows':78,'locs':66,'plait':74,'twinbraids':74,'sidebraid':74,'spacebuns':74,'topknot':78,'curtains':70,'spiky':66,'fauxhawk':60,'hijab':64}
def reused(character,name,colors):
 p=REF/character/(character+'--'+name+'.svg');g=copy.deepcopy(part(E.parse(p).getroot(),name))
 for q in g.iter():
  q.attrib.pop('class',None);q.attrib.pop('style',None)
  for key in ['fill','stroke']:
   if q.get(key) in colors:q.set(key,colors[q.get(key)])
 return g

def star(x,y,r=8.5):
 pts=[]
 for i in range(10):
  a=-math.pi/2+i*math.pi/5;rad=r if i%2==0 else r*.46;pts.append((x+math.cos(a)*rad,y+math.sin(a)*rad))
 return 'M'+' L'.join(f'{x:.3f} {y:.3f}' for x,y in pts)+'Z'

def accessory_geometry(style,hair='crop'):
 top=TOP[hair];rx=91 if hair=='afro' else 57;depth=96 if hair=='afro' else 58
 g=el('g',data_part='head-accessory',data_item_id=style,data_hairstyle=hair,data_contact_top=top,fill='none',stroke=INK,stroke_width=2.2,stroke_linecap='round',stroke_linejoin='round')
 def shape(d,c,w=2):g.append(el('path',d=d,fill=c,stroke_width=w))
 def line(d,c=INK,w=1.6):g.append(el('path',d=d,stroke=c,stroke_width=w))
 if style=='crown_lexicon':
  # Native crown sits a little into the hair; the base remains a curved circlet.
  wrap=el('g',transform=f'translate(0 {top+12-89})')
  crown=reused('king','crown',{'#e5bd61':'#F2B33D','#b44349':'#C05254'});wrap.append(crown)
  wrap.append(el('path',d='M129 85 Q160 91 191 85 L191 91 Q160 97 129 91Z',fill='#E3A130',stroke_width=1.5));g.append(wrap)
 elif style=='crown_flowers':
  # A shallow U-shaped circlet, with a fuller upward-growing flower cluster.
  y0=top+9;cy=top+33;left=160-rx*.70;right=160+rx*.70
  line(f'M{left} {y0} Q160 {cy} {right} {y0}','#4E7A3A',3)
  colors=[('#F28DB2','#F2B33D'),('#F7D154','#E07B39'),('#FFFFFF','#F2B33D'),('#B79CE8','#F7D154')]
  def bloom(x,y,scale,index):
   petal,centre=colors[index%4];flower=reused('contessa','flower',{'#ee8191':petal,'#f6c76d':centre});flower.set('transform',f'translate({x} {y}) scale({scale}) translate(-197 -87)');g.append(flower)
  # Raised rear blossoms add volume, rather than a single thin flower line.
  for i in range(7):
   t=(i+.5)/7;x=(1-t)*left+t*right;y=(1-t)**2*y0+2*(1-t)*t*cy+t*t*y0
   g.append(el('ellipse',cx=x,cy=y-7,rx=7,ry=3,fill='#6FA35A',stroke_width=1,transform=f'rotate({-35 if i<3 else 35} {x} {y-7})'))
   bloom(x,y-9,.71,i+2)
  for i in range(11):
   t=i/10;x=(1-t)*left+t*right;y=(1-t)**2*y0+2*(1-t)*t*cy+t*t*y0
   bloom(x,y,.77 if i%2 else .83,i)
 elif style=='headband_cat':
  arc=f'M{160-rx*.91} {top+depth} C{160-rx*1.02} {top+depth*.38} {160-rx*.61} {top} 160 {top} C{160+rx*.61} {top} {160+rx*1.02} {top+depth*.38} {160+rx*.91} {top+depth}'
  line(arc,INK,5);line(arc,'#E77FA6',2.9)
  for di in [-1,1]:
   x=160+di*rx*.63
   shape(f'M{x+di*10} {top+26} L{x+di*9} {top-10} Q{x+di*8} {top-13} {x+di*5} {top-10} L{x-di*15} {top+8}Z','#3A3346',1.8)
   shape(f'M{x+di*5} {top+16} L{x+di*5} {top-1} L{x-di*7} {top+8}Z','#F0A0B8',.8)
 elif style=='clips_star':
  positions=[(108,128),(212,128)] if hair=='hijab' else [(105,93),(215,93)] if hair=='afro' else [(116,123),(204,123)]
  for i,(x,y) in enumerate(positions):
   line(f'M{x-5} {y+4} L{x+5} {y-4}','#B78C32',2.8)
   shape(star(x,y),'#F7D154' if i==0 else '#F28DB2',1.5)
   g.append(el('circle',cx=x-2,cy=y-3,r=1.4,fill='#FFF',stroke='none',opacity='.85'))
 return g


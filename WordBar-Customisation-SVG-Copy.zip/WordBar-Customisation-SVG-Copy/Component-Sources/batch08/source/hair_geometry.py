from pathlib import Path
import xml.etree.ElementTree as E
import copy
N='http://www.w3.org/2000/svg'
INK='#452a20'
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def save(r,p):p.parent.mkdir(parents=True,exist_ok=True);E.ElementTree(r).write(p,encoding='unicode',xml_declaration=True)
def light(c,m=.24):return '#'+''.join(f'{round(int(c[i:i+2],16)+(255-int(c[i:i+2],16))*m):02x}' for i in [1,3,5])
def ref_component(character,name,color):
 p=Path(__file__).parent/'reused'/character/(character+'--'+name+'.svg')
 g=copy.deepcopy(part(E.parse(p).getroot(),name))
 for q in g.iter():
  q.attrib.pop('style',None);q.attrib.pop('class',None)
  if q.get('fill') and q.get('fill')!='none':q.set('fill',color)
  if q.get('stroke') and q.get('stroke') not in ['none',INK]:q.set('stroke',light(color))
 return g

def hair_geometry(style,color,skin='#E8B88A',cloth='#2F3E66'):
 back=el('g',data_part='hair-back',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 front=el('g',data_part='hair-front',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 high=light(color)
 def shape(d,container=front,fill=None,stroke=None,rule=None):
  q=el('path',d=d,fill=fill or color)
  if stroke:q.set('stroke',stroke)
  if rule:q.set('fill-rule',rule)
  container.append(q)
 def detail(d,container=front,w=2.2,c=None):container.append(el('path',d=d,fill='none',stroke=c or high,stroke_width=w))
 if style=='spiky':
  back.append(ref_component('benji','spiky-hair-back',color))
  # Solid crown flows into the source spike silhouette without an inset outer contour.
  shape('M107 155 Q98 131 107 108 C114 85 133 77 160 76 C188 74 210 84 216 111 L212 158 L202 134 Q190 122 180 110 Q176 127 164 128 L168 109 Q154 129 143 124 L148 107 Q132 132 118 134 L115 163Z',stroke='none')
  detail('M115 163 L118 134 Q132 132 148 107 L143 124 Q154 129 168 109 L164 128 Q176 127 180 110 Q190 122 202 134 L212 158',w=2.1,c=INK)
  detail('M112 104 L106 96 M128 96 L125 83 M151 91 L153 78 M175 91 L172 76 M199 104 L207 96',w=2)
 elif style=='fauxhawk':
  shape('M110 151 L108 132 C108 103 131 80 160 80 C189 80 212 103 212 132 L210 151 L203 150 L199 130 Q180 119 160 122 Q140 119 121 130 L117 151Z')
  shape('M141 120 Q138 92 145 71 L151 79 L160 50 L168 75 L176 64 Q187 93 180 120 Q160 113 141 120Z')
  detail('M149 106 L151 89 M160 105 L160 72 M171 106 L173 88 M121 118 Q125 106 132 102 M199 118 Q195 106 188 102',w=1.9)
 elif style=='hijab':
  # Rounded fabric dome; inner face window contains the full eye/eyelash area.
  outer='M83 271 C85 248 94 236 101 224 L96 139 C96 100 122 70 160 64 C198 70 224 100 224 139 L220 224 C227 236 236 248 239 271 C215 282 191 288 160 285 C132 284 105 279 83 271Z'
  opening='M115 134 C116 110 137 98 160 98 C183 98 204 110 205 134 L210 171 Q204 199 178 218 Q160 230 142 218 Q116 199 110 171Z'
  shape(outer,back,fill=cloth)
  shape(outer+' '+opening,fill=cloth,rule='evenodd')
  # Single fabric fill with two open fold curves; no separate neck panel.
  detail('M106 131 Q111 92 146 81 M213 151 L211 199',w=2,c=light(cloth,.28))
  detail('M113 224 C140 242 179 246 211 232 M102 247 C134 268 184 275 226 263',w=1.8,c=light(cloth,.24))
 return back,front


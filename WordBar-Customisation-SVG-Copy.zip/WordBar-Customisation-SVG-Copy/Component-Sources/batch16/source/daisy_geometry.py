from pathlib import Path
import xml.etree.ElementTree as E
import copy
N='http://www.w3.org/2000/svg'
INK='#452a20'
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def clip_geometry(hair='crop'):
 # Hair surface contacts, in the shared head-local coordinate system.
 x,y=(215,93) if hair=='afro' else (212,128) if hair=='hijab' else (200,110) if hair=='bald' else (204,121)
 g=el('g',data_part='daisy-hairclip',data_item_id='clip_daisy',data_hairstyle=hair,data_contact_x=x,data_contact_y=y,stroke=INK,stroke_width=1.3,stroke_linecap='round',stroke_linejoin='round')
 g.append(el('path',d=f'M{x-7} {y+4} L{x+6} {y-4}',fill='none',stroke='#B78C32',stroke_width=3))
 flower=copy.deepcopy(part(E.parse(Path(__file__).parent/'reused/contessa--flower.svg').getroot(),'flower'))
 for q in flower.iter():
  q.attrib.pop('class',None);q.attrib.pop('style',None)
  if q.get('fill')=='#ee8191':q.set('fill','#FFFCF4')
  if q.get('fill')=='#f6c76d':q.set('fill','#F2B33D')
 flower.set('transform',f'translate({x} {y}) rotate(-12) scale(.86) translate(-197 -87)');g.append(flower)
 return g

def apply_clip(root,hair='crop'):
 part(root,'custom-head').append(clip_geometry(hair));return root

from pathlib import Path
import xml.etree.ElementTree as E
import copy
N='http://www.w3.org/2000/svg'
INK='#452a20'
REF=Path(__file__).parent/'reused'
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def reused(character,name,colors):
 p=REF/character/(character+'--'+name+'.svg');g=copy.deepcopy(part(E.parse(p).getroot(),name))
 for q in g.iter():
  q.attrib.pop('class',None);q.attrib.pop('style',None)
  for key in ['fill','stroke']:
   if q.get(key) in colors:q.set(key,colors[q.get(key)])
 return g

def hat_geometry(style):
 g=el('g',data_part='hat',data_hat_id=style,fill='none',stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 def shape(d,c,sw=2.4):g.append(el('path',d=d,fill=c,stroke_width=sw))
 def line(d,c,w=1.5):g.append(el('path',d=d,stroke=c,stroke_width=w))
 if style=='cap_scarlet':
  fit=el('g',transform='translate(160 0) scale(.88 1) translate(-160 0) translate(0 7)')
  fit.append(reused('baxter','cap-shell',{'#538c87':'#C0392B','#3d5069':'#A23229','#3a6866':'#A23229','#39716e':'#8E3027'}))
  fit.append(reused('baxter','cap-brim',{'#354b66':'#A23229','#6e8b9f':'#DD7563'}));g.append(fit)
 elif style=='hat_bobble':
  knit=reused('dave','ribbed-beanie',{'#f0ddbf':'#4E8FCF','#b3a086':'#376A9E','#b5a388':'#376A9E'})
  knit[0].set('d','M108 117 C107 81 129 54 160 54 C191 54 213 81 212 117Z')
  knit[1].set('d','M108 110 Q160 94 212 110 L212 128 Q160 112 108 128Z')
  knit[2].set('d','M116 103 Q119 80 130 65 M132 99 L141 59 M160 97 L160 56 M188 99 L179 59 M204 103 Q201 80 190 65')
  knit[3].set('d','M111 119 Q160 105 209 119')
  g.append(knit)
  # Inset stripe follows the narrowed dome and ends inside the fabric.
  line('M117 86 Q160 68 203 86','#F4EDE2',4.5)
  g.append(el('circle',cx=160,cy=49,r=12,fill='#F4EDE2',stroke_width=2.2));line('M153 46 Q156 42 159 46 M160 54 Q164 50 168 54','#CFC6B6',1.5)
 elif style=='hat_chef':
  shape('M109 108 C91 105 88 85 102 77 C100 60 119 49 135 57 C146 43 174 43 185 57 C202 48 221 62 218 78 C234 87 226 106 211 108 L207 124 Q160 116 113 124Z','#F4F0E6')
  line('M126 66 Q122 84 125 103 M160 57 L160 102 M194 66 Q199 83 195 103','#C9C1B2',1.7)
  shape('M108 106 Q160 96 212 106 L211 128 Q160 118 109 128Z','#F7F4EE')
  line('M111 118 Q160 109 209 118','#D9D2C5',1.5)
 elif style=='hat_pirate':
  fit=el('g',data_outer_scale='1.30',transform='translate(160 125) scale(1.3) translate(-160 -125) translate(160 0) scale(.95 1) translate(-160 0) translate(0 2)');fit.append(reused('pirate','tricorn',{'#54382c':'#2E2A36','#d4ac64':'#D8A521'}));g.append(fit)
  # The fitted inner band keeps its original head width as the outer hat grows.
  shape('M109 120 Q160 109 211 120 L211 128 Q160 117 109 128Z','#2E2A36',1.8)
  # Tiny simple skull and crossed bones, kept above the brow zone.
  line('M153 106 L167 112 M153 112 L167 106','#F4F0E8',2.6)
  g.append(el('circle',cx=160,cy=98,r=6,fill='#F4F0E8',stroke_width=1.3));g.append(el('rect',x=157,y=101,width=6,height=5,rx=1.5,fill='#F4F0E8',stroke_width=1.1))
  for x in [158,162]:g.append(el('circle',cx=x,cy=98,r=1.1,fill=INK,stroke='none'))
 return g

def apply_hat(r,style,hair='crop',haircolor='#4E3A2D',uid='hat'):
 h=part(r,'custom-head');defs=el('defs');cid=uid+'-hat-tuck';cp=el('clipPath',id=cid,clipPathUnits='userSpaceOnUse')
 # Rounded tuck boundary prevents straight clipped shelves beside the hat.
 cp.append(el('path',d='M160 112 C192 112 213 126 218 147 C224 176 240 192 270 205 L320 205 V500 H0 V205 H50 C80 192 96 176 102 147 C107 126 128 112 160 112Z'))
 defs.append(cp);r.insert(0,defs)
 for q in r.iter():
  if q.get('data-part') in ['hair-back','hair-front']:q.set('clip-path','url(#'+cid+')')
 if hair in ['afro','spacebuns','topknot','spiky','fauxhawk','puffs','frizz']:
  for q in r.iter():
   if q.get('data-part') in ['hair-back','hair-front']:q.set('display','none')
  tucked=el('g',data_part='hair-front-tucked',fill=haircolor,stroke=INK,stroke_width=2.4,stroke_linejoin='round',stroke_linecap='round')
  if hair in ['afro','puffs','frizz']:
   d='M109 151 L107 132 C107 102 130 82 160 82 C190 82 213 102 213 132 L211 151 L205 149 L202 131 Q195 137 189 128 Q180 135 173 125 Q163 135 155 126 Q145 135 138 127 Q130 136 121 131 L115 151Z'
  else:d='M109 151 L107 132 C107 102 130 82 160 82 C190 82 213 102 213 132 L211 151 L205 149 L202 132 Q185 126 176 115 Q171 128 159 122 Q147 130 139 120 Q128 132 117 132 L115 151Z'
  tucked.append(el('path',d=d));h.insert(list(h).index(part(r,'face-customized')),tucked)
 hat=hat_geometry(style);h.append(hat)
 return r

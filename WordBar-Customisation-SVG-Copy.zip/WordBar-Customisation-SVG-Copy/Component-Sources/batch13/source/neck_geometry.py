from pathlib import Path
import xml.etree.ElementTree as E
import copy
N='http://www.w3.org/2000/svg'
INK='#452a20'
REF=Path(__file__).parent/'reused'
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def reused(character,name,colors):
 p=REF/character/(character+'--'+name+'.svg');g=copy.deepcopy(part(E.parse(p).getroot(),name))
 for q in g.iter():
  q.attrib.pop('class',None);q.attrib.pop('style',None)
  for key in ['fill','stroke']:
   if q.get(key) in colors:q.set(key,colors[q.get(key)])
 return g

def neck_geometry(style,uid='neck'):
 g=el('g',data_part='neck-accessory',data_item_id=style,data_coordinate_space='body',fill='none',stroke=INK,stroke_width=2,stroke_linecap='round',stroke_linejoin='round')
 def shape(d,c,w=2):g.append(el('path',d=d,fill=c,stroke_width=w))
 def line(d,c,w=1.6):g.append(el('path',d=d,stroke=c,stroke_width=w))
 if style in ['scarf_cosy','scarf_rainbow']:
  tail='M169 241 C181 248 190 271 190 312 Q181 323 166 316 C170 290 162 268 163 250Z'
  wrap='M135 223 C146 233 174 233 185 223 L194 240 C190 257 174 269 159 267 C141 265 127 253 126 240Z'
  fringe='M168 319 L167 324 M174 321 L174 327 M180 320 L181 326 M186 317 L188 322'
  if style=='scarf_cosy':
   shape(tail,'#7A3B3B')
   line('M176 266 C183 282 184 298 178 313','#A76962',1.5)
   line(fringe,'#7A3B3B',2)
   shape(wrap,'#7A3B3B')
   line('M133 235 C147 248 174 247 187 234 M133 248 C145 260 165 266 181 254','#A76962',1.6)
  else:
   colors=['#E5484D','#F28C38','#F7D154','#5DB35D','#4E8FCF'];defs=el('defs');g.append(defs)
   for name,d in [('tail',tail),('wrap',wrap)]:
    cp=el('clipPath',id=uid+'-'+name,clipPathUnits='userSpaceOnUse');cp.append(el('path',d=d));defs.append(cp)
   stripes=el('g',clip_path='url(#'+uid+'-tail)',stroke='none');g.append(stripes)
   for i,c in enumerate(colors):stripes.append(el('rect',x=120,y=241+i*18,width=82,height=18,fill=c))
   shape(tail,'none');line(fringe,'#4E8FCF',2)
   shape(wrap,colors[0])
   stripes=el('g',clip_path='url(#'+uid+'-wrap)',stroke='none');g.append(stripes)
   for i,c in enumerate(colors[1:],1):
    y=218+i*7;end=y+(24 if i==4 else 7.2)
    stripes.append(el('path',d=f'M120 {y} Q160 {y+24} 200 {y} L200 {end} Q160 {end+24} 120 {end}Z',fill=c))
   shape(wrap,'none')
 elif style=='necklace_heart':
  line('M145 226 Q160 246 175 226 M160 236 V243','#D8A521',1.8)
  shape('M160 254 C146 245 152 238 160 244 C168 238 174 245 160 254Z','#D8547A',1.5)
  line('M155 244 Q156 242 158 244','#F6B2C6',1.1)
 elif style=='bowtie_dapper':
  bow=reused('devereux','bow-tie',{'#984d40':'#3E5C8E','#b36754':'#2C4368'})
  bow.set('transform','translate(160 239) scale(1.12 1) translate(-160.5 -250)');g.append(bow)
  line('M147 236 L153 239 M173 236 L167 239','#7E9FC6',1.1)
 return g

def apply_neck(r,style,uid='neck'):
 body=next(q for q in r.iter() if any(c.get('data-part')=='legs' for c in q))
 # Garment/apron < neck item < braid middle < head and long beard/hijab.
 index=list(body).index(part(r,'apron'))+1;body.insert(index,neck_geometry(style,uid));return r


from pathlib import Path
import xml.etree.ElementTree as E
import copy
N='http://www.w3.org/2000/svg'
INK='#452a20'
REF=Path(__file__).parent/'reused'
TOP={'bald': 82, 'crop': 77, 'flop': 67, 'side': 76, 'buzz': 80, 'shortquiff': 65, 'pixie': 72, 'bob': 68, 'bun': 70, 'ponytail': 70, 'longstraight': 66, 'longwave': 66, 'waves': 74, 'curls': 65, 'puffs': 84, 'frizz': 68, 'afro': 28, 'cornrows': 78, 'locs': 66, 'plait': 74, 'twinbraids': 74, 'sidebraid': 74, 'spacebuns': 74, 'topknot': 78, 'curtains': 70, 'spiky': 66, 'fauxhawk': 60, 'hijab': 64}
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def reused(character,name):
 p=REF/character/(character+'--'+name+'.svg');g=copy.deepcopy(part(E.parse(p).getroot(),name))
 for q in g.iter():q.attrib.pop('class',None);q.attrib.pop('style',None)
 return g

def wearable_geometry(style,hair='crop',uid='item'):
 rear=el('g',data_part='wearable-rear',data_item_id=style,fill='none',stroke=INK,stroke_width=2,stroke_linecap='round',stroke_linejoin='round')
 middle=el('g',data_part='wearable-middle',data_item_id=style,fill='none',stroke=INK,stroke_width=2,stroke_linecap='round',stroke_linejoin='round')
 front=el('g',data_part='wearable-front',data_item_id=style,fill='none',stroke=INK,stroke_width=2.2,stroke_linecap='round',stroke_linejoin='round')
 def shape(d,c,into=front,w=2.2):into.append(el('path',d=d,fill=c,stroke_width=w))
 def line(d,c=INK,w=2,into=front):into.append(el('path',d=d,stroke=c,stroke_width=w))
 if style=='headset_pro':
  top=83 if hair=='fauxhawk' else TOP[hair]+3
  arc=f'M104 165 C102 113 111 {top} 160 {top} C209 {top} 218 113 216 165' if hair!='afro' else f'M104 165 C69 126 68 {top} 160 {top} C252 {top} 251 126 216 165'
  line(arc,INK,6.2);line(arc,'#5C5870',3.7)
  for x in [99,207]:
   front.append(el('rect',x=x,y=157,width=14,height=31,rx=6.5,fill='#3E3A4A',stroke_width=1.8));front.append(el('path',d=f'M{x+4} 162 V181',stroke='#716C82',stroke_width=1.8))
  line('M107 186 C111 202 122 207 140 205','#3E3A4A',3.7)
  front.append(el('rect',x=137,y=201,width=12,height=7,rx=3.4,fill='#5C5870',stroke_width=1.5))
 elif style=='pencil_ear':
  pencil=el('g',transform='translate(209 178) rotate(5) scale(1 .78)',stroke_width=1.3)
  pencil.append(el('rect',x=-3,y=-9,width=6,height=9,rx=1.5,fill='#E88A9B'))
  pencil.append(el('rect',x=-3,y=-15,width=6,height=6,fill='#B8B8C4'))
  pencil.append(el('rect',x=-3,y=-51,width=6,height=36,fill='#F2C94C'))
  pencil.append(el('path',d='M0 -17 V-49',stroke='#D9A826',stroke_width=1))
  pencil.append(el('path',d='M-3 -51 L0 -61 L3 -51Z',fill='#EDCFA4'))
  pencil.append(el('path',d='M-1 -58 L0 -61 L1 -58Z',fill=INK,stroke='none'))
  rear.append(copy.deepcopy(pencil))
  # Shaft rests against the hair; its lower root remains behind the real ear.
  if hair!='hijab':
   defs=el('defs');cp=el('clipPath',id=uid+'-pencil-shaft',clipPathUnits='userSpaceOnUse');cp.append(el('rect',x=195,y=80,width=60,height=75));defs.append(cp);front.append(defs)
   wrap=el('g',clip_path='url(#'+uid+'-pencil-shaft)');wrap.append(pencil);front.append(wrap)
 elif style=='earrings_gold':
  hoops=reused('marchetti','earrings')
  for q in hoops:
   q.set('cy','191');q.set('r','7.4');q.set('fill','none');q.set('stroke','#D8A521');q.set('stroke-width','2.6')
  middle.append(hoops)
  for x in [108,212]:
   middle.append(el('circle',cx=x,cy=183,r=2.1,fill='#F2B33D',stroke_width=1))
   line(f'M{x-4} 187 Q{x-5} 190 {x-4} 193','#FFF3BB',1.1,middle)
 elif style in ['sunglasses_cool','sunglasses_heart']:
  line('M112 153 L108 161 M208 153 L212 161',INK,2.3,middle)
  if style=='sunglasses_cool':
   line('M112 145 H208',INK,3.2)
   for cx in [134,186]:
    shape(f'M{cx-22} 145 H{cx+22} L{cx+19} 170 Q{cx+16} 181 {cx} 181 Q{cx-16} 181 {cx-19} 170Z','#2E2A36')
    line(f'M{cx-14} 151 Q{cx-13} 157 {cx-8} 159','#8C93A8',2)
   line('M156 151 Q160 147 164 151',INK,2.2)
  else:
   for cx in [134,186]:
    shape(f'M{cx} 185 C{cx-29} 166 {cx-23} 139 {cx-11} 139 C{cx-5} 139 {cx-1} 144 {cx} 148 C{cx+1} 144 {cx+5} 139 {cx+11} 139 C{cx+23} 139 {cx+29} 166 {cx} 185Z','#D63F76')
    line(f'M{cx-15} 150 Q{cx-14} 145 {cx-9} 146','#FFF',1.8)
   line('M153 154 Q160 149 167 154',INK,2.2)
 return rear,middle,front

def apply_wearable(r,style,hair='crop',uid='item'):
 h=part(r,'custom-head');rear,middle,front=wearable_geometry(style,hair,uid);foundation=part(r,'head-foundation');h.insert(list(h).index(foundation),rear)
 hf=next((q for q in h if q.get('data-part')=='hair-front'),part(r,'face-customized'));h.insert(list(h).index(hf),middle);h.append(front)
 if style.startswith('sunglasses_'):part(r,'eyes').set('display','none')
 return r

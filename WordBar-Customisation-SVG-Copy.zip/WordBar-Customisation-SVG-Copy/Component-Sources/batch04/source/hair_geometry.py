from pathlib import Path
import xml.etree.ElementTree as E
import copy
N="http://www.w3.org/2000/svg"
INK="#452a20"
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def save(r,p):p.parent.mkdir(parents=True,exist_ok=True);E.ElementTree(r).write(p,encoding='unicode',xml_declaration=True)
def light(c,m=.24):return '#'+''.join(f'{round(int(c[i:i+2],16)+(255-int(c[i:i+2],16))*m):02x}' for i in [1,3,5])
def source(name,color):
 p=Path(__file__).parent/'reused'/('leo--'+name+'.svg');g=copy.deepcopy(part(E.parse(p).getroot(),name))
 for q in g.iter():
  q.attrib.pop('style',None);q.attrib.pop('class',None)
  if q.get('fill') and q.get('fill')!='none':q.set('fill',color)
  if q.get('stroke') and q.get('stroke') not in ['none',INK]:q.set('stroke',light(color))
 return g

def hair_geometry(style,color):
 back=el('g',data_part='hair-back',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 front=el('g',data_part='hair-front',data_hairstyle=style,fill=color,stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 high=light(color)
 def shape(d,container=front):container.append(el('path',d=d,fill=color))
 def detail(d,w=2.2):front.append(el('path',d=d,fill='none',stroke=high,stroke_width=w))
 if style=='flop':
  back.append(source('hair-back',color));front.append(source('side-swept-fringe',color))
 elif style=='crop':
  shape('M108 153 L104 126 C102 99 126 76 160 77 C194 76 218 99 216 126 L209 155 L200 129 Q183 133 173 116 Q158 128 143 116 Q132 130 119 126 L114 153Z')
  detail('M121 109 Q136 98 149 102 M171 99 Q187 98 199 113')
 elif style=='side':
  # Refitted side-swept structure inspired by Freya; crown covers approved skull.
  shape('M108 157 Q98 136 104 112 Q110 88 139 79 Q161 70 184 78 Q210 82 216 109 Q221 132 211 157 L204 165 L200 130 Q194 116 182 105 Q165 123 144 127 L151 112 Q135 133 118 137 L115 166Z')
  detail('M114 116 Q130 91 158 91 M121 125 Q139 105 166 99 M183 89 Q179 102 170 109 M191 99 Q205 112 207 137')
 elif style=='buzz':
  shape('M111 149 L109 135 C109 105 131 80 160 80 C189 80 211 105 211 135 L209 149 L203 148 L200 124 Q186 110 175 119 Q160 126 145 119 Q134 111 120 124 L117 149Z')
  detail('M124 108 l2 -3 M139 98 l2 -2 M156 94 l1 -2 M174 98 l-1 -2 M191 108 l-2 -3 M134 111 l2 -2 M164 108 l0 -2 M184 113 l-2 -2',1.4)
 elif style=='shortquiff':
  shape('M109 157 Q98 133 108 100 Q119 79 141 78 Q166 70 194 78 Q213 88 214 117 L210 158 L202 163 L198 130 L118 133 L117 162Z',back)
  shape('M106 143 Q96 121 108 100 Q117 84 139 76 Q148 64 143 60 Q166 58 180 68 Q193 73 199 85 Q209 95 207 112 L201 131 Q190 125 184 111 Q173 125 154 124 L164 109 Q145 133 122 130 L115 151Z')
  detail('M117 111 Q131 93 155 88 Q165 81 160 73 M128 119 Q150 102 174 94 M180 81 Q192 90 197 106 M113 130 Q112 123 115 119')
 elif style=='pixie':
  shape('M108 156 Q99 132 105 111 Q111 95 126 79 Q133 69 144 74 L153 63 L165 74 Q188 70 206 79 L202 91 Q218 104 216 127 L210 157 L203 169 L199 132 L190 119 Q180 131 167 134 L171 115 Q157 136 141 132 L146 115 Q132 135 118 136 L115 166Z')
  detail('M115 116 Q123 98 141 92 M140 99 Q152 88 155 79 M164 98 Q181 85 194 88 M181 109 Q194 99 204 115 M205 133 L207 145',2)
 return back,front

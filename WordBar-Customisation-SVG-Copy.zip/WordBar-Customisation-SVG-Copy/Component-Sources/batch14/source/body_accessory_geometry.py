from pathlib import Path
import xml.etree.ElementTree as E
import copy,math
N='http://www.w3.org/2000/svg'
INK='#452a20'
REF=Path(__file__).parent/'reused'
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(q for q in r.iter() if q.get('data-part')==n)
def reused(character,name,colors):
 p=REF/character/(character+'--'+name+'.svg');g=copy.deepcopy(part(E.parse(p).getroot(),name))
 for q in g.iter():
  q.attrib.pop('class',None);q.attrib.pop('style',None)
  for key in ['fill','stroke']:
   if q.get(key) in colors:q.set(key,colors[q.get(key)])
 return g

def star(cx,cy,r):
 pts=[]
 for i in range(10):
  a=-math.pi/2+i*math.pi/5;rad=r if i%2==0 else r*.46;pts.append((cx+rad*math.cos(a),cy+rad*math.sin(a)))
 return 'M'+' L'.join(f'{x:.3f} {y:.3f}' for x,y in pts)+'Z'

def body_geometry(style,uid='body'):
 back=el('g',data_part='body-item-back',data_item_id=style,fill='none',stroke=INK,stroke_width=2.4,stroke_linecap='round',stroke_linejoin='round')
 front=el('g',data_part='body-item-front',data_item_id=style,fill='none',stroke=INK,stroke_width=2.1,stroke_linecap='round',stroke_linejoin='round')
 if style=='watch_classic':
  watch=reused('priyanka','watch',{'#dcc995':'#8A5A2E','#f2e6ca':'#F4F0E8','#6c6652':INK});watch.set('transform','translate(91 334) translate(-231 -331)');watch.set('data-attachment','fore-l');front.append(watch)
 elif style=='bracelet_beads':
  for i,(x,c) in enumerate(zip([83.5,90,96.5,103],['#6BC5B8','#D8547A','#F2B33D','#7FA65A'])):
   y=335-abs(i-1.5)*.8;front.append(el('circle',cx=x,cy=y,r=3.2,fill=c,stroke_width=1.1))
 elif style=='belt_buckle':
  belt=reused('captain','belt',{'#242e40':'#5C4033','#ddb85e':'#D8A521','#303d55':'#5C4033'});belt.set('transform','translate(0 -24)');front.append(belt)
 elif style=='badge_star':
  front.append(el('circle',cx=142,cy=269,r=7.4,fill='#F2B33D',stroke_width=1.5));front.append(el('path',d=star(142,269,4.7),fill='#FFF',stroke='none'))
 elif style=='cape_hero':
  palette={'#df6f5a':'#C0392B','#b64639':'#922D24','#f5ca60':'#F2B33D'}
  back.append(reused('hero','red-cape',palette));front.append(reused('hero','cape-clasps',palette))
 return back,front

def apply_body_item(r,style,uid='body'):
 back,front=body_geometry(style,uid)
 if style in ['watch_classic','bracelet_beads']:
  joint='fore-l' if style=='watch_classic' else 'fore-r';front.set('data-attachment',joint)
  fore=next(q for q in r.iter() if q.get('data-joint')==joint);fore[0].append(front)
 else:
  body=next(q for q in r.iter() if any(c.get('data-part')=='legs' for c in q))
  if len(back):body.insert(0,back)
  body.insert(list(body).index(part(r,'apron'))+1,front)
 return r


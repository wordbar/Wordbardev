import xml.etree.ElementTree as E
N='http://www.w3.org/2000/svg'
def el(t,**a):return E.Element('{'+N+'}'+t,{k.replace('_','-'):str(v) for k,v in a.items()})
def glasses_geometry(style,color='#2E2440',eye='round'):
 arms=el('g',data_part='glasses-temples',fill='none',stroke=color,stroke_width=1.9,stroke_linecap='round',stroke_linejoin='round')
 frame=el('g',data_part='glasses-frame',data_glasses_style=style,data_eye_shape=eye,fill='none',stroke=color,stroke_width=2.1,stroke_linecap='round',stroke_linejoin='round')
 if style=='none':return arms,frame
 # Same eye centres as reused Scientist/Steinberg and Adeyemi frames.
 # Fit to worst open expression (wow) without changing approved eye geometry.
 up={'round':13.07,'tall':15,'almond':7.3,'sleepy':5,'wide':14.2,'upturned':11.2}[eye]*1.08
 dn={'round':13.07,'tall':14,'almond':7.8,'sleepy':10.2,'wide':13.8,'upturned':10.8}[eye]*1.08
 mh=max(up,dn);hw=21;ry=mh+5.3
 if style=='glasses':hw=ry=max(20,mh+5.3)
 elif style=='glasses_biground':hw=ry=max(22,mh+6.7)
 elif style=='glasses_oval':hw=22.6;ry=mh+4.7
 elif style=='glasses_square':hw=20.7;ry=max(18,mh+4.7)
 elif style=='glasses_rect':hw=22.3;ry=max(13,mh+4.5)
 elif style=='glasses_cateye':hw=21.5;ry=mh+5.1
 elif style=='glasses_halfrim':hw=21.5;ry=max(15,mh+5)
 frame.set('data-half-width',str(hw));frame.set('data-half-height',str(ry))
 for cx,di in [(134,-1),(186,1)]:
  x0=cx-hw;x1=cx+hw;y0=163-ry;y1=163+ry
  if style in ['glasses','glasses_biground']:q=el('circle',cx=cx,cy=163,r=hw)
  elif style=='glasses_oval':q=el('ellipse',cx=cx,cy=163,rx=hw,ry=ry)
  elif style=='glasses_cateye':
   # Mirror a broad, gently lifted outer corner; round lower lens.
   q=el('path',d=f'M{cx-di*hw} 162 C{cx-di*hw} {y0+2} {cx-di*9} {y0-1} {cx+di*(hw+1)} {y0-2} L{cx+di*hw} 163 C{cx+di*hw} {163+ry*1.3} {cx-di*hw} {163+ry*1.3} {cx-di*hw} 162Z')
  else:q=el('rect',x=x0,y=y0,width=hw*2,height=ry*2,rx=6 if style=='glasses_square' else 4.5)
  q.set('data-part','lens-outline');q.set('fill','none');frame.append(q)
  if style=='glasses_halfrim':
   q.set('stroke-width','.85');q.set('stroke-opacity','.65')
   frame.append(el('path',d=f'M{x0} {y0+7} L{x0} {y0+4.5} Q{x0} {y0} {x0+4.5} {y0} L{x1-4.5} {y0} Q{x1} {y0} {x1} {y0+4.5} L{x1} {y0+7}',stroke_width=2.8))
  ox=cx+di*hw
  arms.append(el('path',d=f'M{ox} 158 Q{ox+di*3} 157 {109 if di<0 else 211} 159'))
 # Raised, compact bridge stays off the nose and between the lenses.
 frame.append(el('path',data_part='glasses-bridge',d=f'M{134+hw} 160 Q160 155.5 {186-hw} 160',stroke_width=1.9))
 return arms,frame


import xml.etree.ElementTree as E
N='http://www.w3.org/2000/svg'
def el(tag,**a):return E.Element('{'+N+'}'+tag,{k.replace('_','-'):str(v) for k,v in a.items()})
def part(r,n):return next(e for e in r.iter() if e.get('data-part')==n)
def repair_sleeves(r,style):
 for side in ['left','right']:
  arm=part(r,'arm-viewer-'+side);joint=next(e for e in arm.iter() if e.get('data-joint')==('fore-l' if side=='left' else 'fore-r'));content=joint[0]
  if style in ['polo','shirt','tee']:
   sleeve=arm[0];hem=arm[1];skin=content[0]
   upper=el('path',data_part='upper-arm-skin-'+side,d='M99 249 Q111 237 123 249 L111 292 A12 12 0 0 1 87 292Z',fill=skin.get('fill','#E8B88A'),stroke='#452a20',stroke_width=2.4)
   if skin.get('style'):upper.set('style',skin.get('style'))
   arm.insert(0,upper);skin.set('d','M87 292 A12 12 0 0 1 111 292 L105 322 L100 341 Q90 347 80 341 L82 315Z')
   arm.remove(sleeve);arm.remove(hem);arm.append(sleeve);arm.append(hem)
  else:
   # Existing separate sleeve pieces share a rounded elbow cap. Keep their cloth,
   # cuffs and clipping; refine the exposed wrist to the approved tee attachment.
   content[0].set('d','M81 329 Q92 335 105 329 L100 341 Q90 347 80 341Z')
  for q in joint.iter():
   if q.get('data-view'):q.set('opacity','1' if q.get('data-view')=='relaxed' else '0')
 r.set('data-review-status','sample-awaiting-review');r.set('data-version','clothing-wave-batch02');r.set('data-garment-style',style);r.attrib.pop('aria-hidden',None);return r
